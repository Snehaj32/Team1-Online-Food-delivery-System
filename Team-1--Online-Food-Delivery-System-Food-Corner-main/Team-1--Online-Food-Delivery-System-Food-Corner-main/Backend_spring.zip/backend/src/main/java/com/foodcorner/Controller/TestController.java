package com.foodcorner.Controller;




import java.util.ArrayList;
import java.util.List;



import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.foodcorner.model.Login;



@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping({ "/login" })
public class TestController {



private List<Login> logins = createList();



@GetMapping(produces = "application/json")
public List<Login> firstPage() {
return logins;
}



@DeleteMapping(path = { "/{id}" })
public Login delete(@PathVariable("id") int id) {
Login deletedEmp = null;
for (Login emp : logins) {
if (emp.getFname().equals(id)) {
logins.remove(emp);
deletedEmp = emp;
break;
}
}
return deletedEmp;
}



@PostMapping
public Login create(@RequestBody Login user) {
logins.add(user);
System.out.println(logins);
return user;
}



private static List<Login> createList() {
List<Login> templogins = new ArrayList<>();
Login emp1 = new Login();
emp1.setFname("admin");
emp1.setAddress("ndia");
emp1.setLname("ademin");
emp1.setMobileno(870);
emp1.setEmail("akashluck.as@gmail.com");
return templogins;



}



}