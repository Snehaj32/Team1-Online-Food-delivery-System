package com.foodcorner.model;

public class Login {
	private String fname;
	private String lname;
	private String email;
	private double mobileno;
	private String address;
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public double getMobileno() {
		return mobileno;
	}
	public void setMobileno(double mobileno) {
		this.mobileno = mobileno;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	 
	public Login() {
		
	}
	
	
	@Override
	public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((address == null) ? 0 : address.hashCode());
	result = prime * result + ((fname == null) ? 0 : fname.hashCode());
	result = prime * result + ((lname == null) ? 0 : lname.hashCode());
	long temp;
	temp = Double.doubleToLongBits(mobileno);
	result = prime * result + (int) (temp ^ (temp >>> 32));
	return result;
	}

	@Override
	public boolean equals(Object obj) {
	if (this == obj)
	return true;
	if (obj == null)
	return false;
	if (getClass() != obj.getClass())
	return false;
	Login other = (Login) obj;
	if (address == null) {
	if (other.address != null)
	return false;
	} else if (!address.equals(other.address))
	return false;
	if (fname == null) {
	if (other.fname != null)
	return false;
	} else if (!fname.equals(other.fname))
	return false;
	if (lname == null) {
	if (other.lname != null)
	return false;
	} else if (!lname.equals(other.lname))
	return false;
	if (Double.doubleToLongBits(mobileno) != Double.doubleToLongBits(other.mobileno))
	return false;
	return true;
	}


}
